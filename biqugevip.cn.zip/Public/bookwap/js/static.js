function chapter_top(){
	
}

function chapter_bottom(){
	//document.writeln("<script src='http:\/\/slb.gedawang.com\/s.php?id=28346'><\/script>");
}

function chapter_linktop(){
	//document.writeln("<script src='http:\/\/slb.gedawang.com\/s.php?id=28381'><\/script>");
}

function chapter_linkbottom(){
	//document.writeln("<script src='http:\/\/slb.gedawang.com\/s.php?id=28347'><\/script>");
}