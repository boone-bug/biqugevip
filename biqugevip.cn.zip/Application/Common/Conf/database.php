<?php
return array(
	'DB_TYPE'	=>  'mysql',
	'DB_HOST'	=>  'localhost',
	'DB_NAME'	=>  'll',
	'DB_USER'	=>  'll',
	'DB_PWD'	=>  'wwwpg88com',
	'DB_PORT'	=>  '3306',
	'DB_PREFIX'	=>  'book_'
);