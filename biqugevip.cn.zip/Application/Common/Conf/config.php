<?php
return array(
	'LOAD_EXT_CONFIG' => 'database,rewrite',
);
