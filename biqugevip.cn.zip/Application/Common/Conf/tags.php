<?php
return array(
	'app_end' => array ('Behavior\CronRunBehavior'),
);